SELECT * FROM students_1.job_history_hr_data
group by EMPLOYEE_ID
having count(JOB_ID)>=2
order by EMPLOYEE_ID asc;

