SELECT 
concat(trim(first_name)," ", trim(last_name)) as Name, HIRE_DATE, COMMISSION_PCT, concat(email, '+' , phone_number) as Email_Number
FROM students_1.employee_hr_data
where SALARY> 12000 or PHONE_NUMBER like "_3%"













-- SELECT concat(trim(FIRST_NAME), " ", trim(LAST_NAME)) as NAME, SALARY, concat(EMAIL, "-",  PHONE_NUMBER) as Email_Name ,HIRE_DATE, JOB_ID, COMMISSION_PCT, MANAGER_ID FROM students_1.employee where SALARY >= 12000 or PHONE_NUMBER like "______3%" order by Name desc;
