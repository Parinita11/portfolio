-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2018 at 02:12 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `productdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `mstuser`
--

CREATE TABLE IF NOT EXISTS `mstuser` (
  `name` varchar(50) NOT NULL,
  `gender` int(5) NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `pswd` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstuser`
--

INSERT INTO `mstuser` (`name`, `gender`, `contactno`, `emailid`, `pswd`, `role`) VALUES
('antima', 2, 12345678910, 'an@gmail.com', 'anti', 'operator'),
('anushka', 2, 7974708443, 'anu@gmail.com', '123', 'admin'),
('pradeep', 1, 7974708443, 'pradeep@gmail.com', '123', 'operator'),
('ram', 1, 7974708443, 'ram@gmail.com', '123', 'admin'),
('varsha', 2, 9876545300, 'var@gmail.com', 'var1', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `productentry`
--

CREATE TABLE IF NOT EXISTS `productentry` (
  `code` int(10) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `qty` int(50) NOT NULL,
  `rate` int(50) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productentry`
--

INSERT INTO `productentry` (`code`, `pname`, `qty`, `rate`) VALUES
(1, 'dvd', 3, 30);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
