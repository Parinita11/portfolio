show databases;

use mysql;

show tables;

desc students;

INSERT INTO students VALUES (1, 'Ramaya', 'Bcom', 6);
INSERT INTO students VALUES (2, 'Akshay', 'Bcom', 3);

select * from students;

CREATE TABLE students (
  id INTEGER PRIMARY KEY,
  name VARCHAR(20) NOT NULL,
  degree TEXT NOT NULL,
  year INTEGER NOT NULL
);
