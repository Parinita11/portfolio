SELECT *
FROM students_1.jobs_hr_data
where MIN_SALARY >9000
;

